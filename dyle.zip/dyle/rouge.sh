cd ~/Documents/GitHub/inlpfun/dyle
# setting for pyrouge - used below
git clone https://github.com/bheinzerling/pyrouge.git

cd pyrouge
apt install libxml-parser-perl
pip install -e .
git clone https://github.com/andersjo/pyrouge.git rouge

cd rouge/tools/ROUGE-1.5.5/data
rm WordNet-2.0.exc.db
perl ./WordNet-2.0-Exceptions/buildExeptionDB.pl ./WordNet-2.0-Exceptions ./smart_common_words.txt ./WordNet-2.0.exc.db
pyrouge_set_rouge_path ~/Documents/GitHub/inlpfun/dyle/pyrouge/rouge/tools/ROUGE-1.5.5
chmod 777 ~/Documents/GitHub/inlpfun/dyle/pyrouge/rouge/tools/ROUGE-1.5.5/ROUGE-1.5.5.pl
python -m pyrouge.test
pip install -U git+https://github.com/pltrdy/pyrouge
git clone https://github.com/pltrdy/files2rouge.git     
cd files2rouge
python setup_rouge.py
python setup.py install
pip install bert-score
pip install rouge