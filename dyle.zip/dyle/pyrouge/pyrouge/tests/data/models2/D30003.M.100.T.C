<html>
<head>
<title>dummy title</title>
</head>
<body bgcolor="white">
<a name="1">[1]</a> <a href="#1" id=1>Former Chilean dictator Augusto Pinochet has been arrested in London at the request of the Spanish government.</a>
<a name="2">[2]</a> <a href="#2" id=2>Pinochet, in London for back surgery, was arrested in his hospital room.</a>
<a name="3">[3]</a> <a href="#3" id=3>Spain is seeking extradition of Pinochet from London to Spain to face charges of murder in the deaths of Spanish citizens in Chile under Pinochet's rule in the 1970s and 80s.</a>
<a name="4">[4]</a> <a href="#4" id=4>The arrest raised confusion in the international community as the legality of the move is debated.</a>
<a name="5">[5]</a> <a href="#5" id=5>Pinochet supporters say that Pinochet's arrest is illegal, claiming he has diplomatic immunity.</a>
<a name="6">[6]</a> <a href="#6" id=6>The final outcome of the extradition request lies with the Spanish courts.</a>
<a name="7">[7]</a> <a href="#7" id=7></a>
</body>
</html>