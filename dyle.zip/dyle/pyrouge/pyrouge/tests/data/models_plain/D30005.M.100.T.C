In the aftermath of the almost simultaneous bombings of U.S. embassies in East Africa, much has been learned of the terrorist network put together and financed by Saudi billionaire Osama bin Laden.
Osama bin Laden, the mastermind of the bombings and U.S. cruise missile attack against a supposed terrorist camp in Afghanistan shortly after the bombings was an attempt not only to disrupt the terrorist network but to get bin Laden himself.
As the investigation into the bombings continues, more is being learned from seized computers and top aides turned informants.
Bin Laden remains in Afghanistan by permission of the Taliban.
